create database project;
use project;
create table user(name varchar(255) ,password varchar(25), userid int);
create table posts(title varchar(255),comment varchar(255));



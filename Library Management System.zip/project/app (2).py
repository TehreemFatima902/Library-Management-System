
from flask import Flask,flash, render_template, request,redirect
import flask
from flask_mysqldb import MySQL

app = Flask(__name__)

app.secret_key = "super secret key"
app.config["MYSQL_HOST"] = "localhost"
app.config["MYSQL_USER"] = "root"
app.config["MYSQL_PASSWORD"] = "2792"
app.config["MYSQL_DB"] = "project"

mysql=MySQL(app)

# def index():

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # Fetch form data
        userDetails = request.form
        name = userDetails['uname']
        password = userDetails['password']
        confirmpass=userDetails['Confirmpass']
        userid= userDetails["userid"]
        print(confirmpass)
        if confirmpass == password:
            
            cur = mysql.connection.cursor()
            cur.execute("INSERT INTO user(name, password,userid) VALUES(%s, %s,%s)",(name, password , userid))
            mysql.connection.commit()
            cur.close()
            return redirect("/login")

    return render_template('index1.html')

@app.route('/Allposts',  methods=['GET', 'POST'])
def Allposts():
    if request.method == 'POST':
        title = request.form['title']
        comment = request.form['comment']
        cursor = mysql.connection.cursor()
        cursor.execute('INSERT INTO posts VALUES ( % s, % s)', (title, comment ))
        mysql.connection.commit()
        return redirect('/posts')
    return render_template('posts.html')
@app.route('/posts')
def posts():
        cursor = mysql.connection.cursor()
        account = cursor.execute('SELECT * FROM posts')
        if account > 0:
            all_posts = cursor.fetchall()
        return render_template('showPosts.html', posts = all_posts)

@app.route('/login',methods=['GET', 'POST'])
def login():
   
    if request.method == 'POST':
        # Fetch form data
        userDetails = request.form
        name = userDetails['uname']
        password = userDetails['password']
        cur = mysql.connection.cursor()
        okay=cur.execute("Select userid  from user where  (name=%s and password=%s)",(name,password))

        if okay>0:
            userid = cur.fetchall()
            global current_user_id 
            current_user_id = userid[0][0]
            return redirect("/Allposts")
        else:
            flash("Username or password incorrect.") 
        mysql.connection.commit()
        cur.close()
        

    return render_template('login.html')     

# @app.route('/Allposts', methods=['GET', 'POST'])
# def Allposts():
    if request.method == 'POST':
        userDetails = request.form
        tite = userDetails['title']
        comment = userDetails['comment']
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO user(uname, password,userid) VALUES(%s, %s,%s)",(name,password,userid))
        mysql.connection.commit()
        cur.close()
    return render_template('posts.html')